import React from "react";
import Playlists from "./componentes/Playlists/Playlists";

function App() {
  return <Playlists />;
}

export default App;
